/* ─────────────────────────────────────────────────────────────
   CASE STUDY REGISTRY
   To add a new case study:
     1. Create a folder:  case-studies/<slug>/
     2. Put its cover image inside:  case-studies/<slug>/cover.jpg
        (and, if the study lives on this site, an index.html in the
         same folder — otherwise point `href` at Figma / PDF / Notion)
     3. Copy a block below, change the fields, done.
   `password` is what you share with a recruiter for THAT study only.
   ───────────────────────────────────────────────────────────── */

window.CASE_STUDIES = [
  {
    slug: "mastercard",
    title: "Mastercard",
    org: "Enterprise · Internal tooling",
    summary: "Internal tool to track the usages of all products Procurement.",
    tags: ["Product usage", "Dashboards", "Enterprise UX"],
    password: "mastercard",
    href: "case-studies/mastercard/index.html",
    cover: "case-studies/mastercard/cover.jpg"
  },
  {
    slug: "procurement-ai",
    title: "Procurement.ai",
    org: "AI product · Sourcing",
    summary: "Procurement cycle.",
    tags: ["Workflow", "AI assistance", "0→1"],
    password: "procurement",
    href: "case-studies/procurement-ai/index.html",
    cover: "case-studies/procurement-ai/cover.jpg"
  },
  {
    slug: "spreadsmart",
    title: "Spreadsmart",
    org: "Financial services",
    summary: "Financial Spreading and Credit Memo.",
    tags: ["Data entry", "Document AI", "Credit"],
    password: "spreadsmart",
    href: "case-studies/spreadsmart/index.html",
    cover: "case-studies/spreadsmart/cover.jpg"
  },
  {
    slug: "credit-risk-staging",
    title: "Credit Risk Staging",
    org: "Risk · Banking",
    summary: "Ai Enabled.",
    tags: ["Risk models", "Explainability", "Review flows"],
    password: "creditrisk",
    href: "case-studies/credit-risk-staging/index.html",
    cover: "case-studies/credit-risk-staging/cover.jpg"
  }
];
